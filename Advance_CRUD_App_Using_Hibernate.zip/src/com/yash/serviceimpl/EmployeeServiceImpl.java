package com.yash.serviceimpl;

import java.util.List;

import com.yash.dao.EmployeeDAO;
import com.yash.daohibernateimpl.EmployeeDAOImpl;
import com.yash.model.Employee;
import com.yash.service.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO employeeDao=null;
	public EmployeeServiceImpl() {
		employeeDao=new EmployeeDAOImpl();
	}
	@Override
	public boolean authenticateEmployee(String userId, String password) {
		return employeeDao.authenticateEmployee(userId, password);
	}

	@Override
	public Employee getEmployeeByUserId(String userId) {
		return employeeDao.getEmployeeById(userId);
	}

	@Override
	public List<Employee> getListOfEmployees() {
		return employeeDao.showAllEmployees();
	}

	@Override
	public boolean register(Employee employee) {
		return employeeDao.insert(employee);
	}
	@Override
	public boolean deleteEmployeeById(Long id) {
		return employeeDao.delete(id);
	}
	@Override
	public boolean editEmployeeById(Long id, Employee employee) {
		
		return employeeDao.update(id,employee);
	}

}
