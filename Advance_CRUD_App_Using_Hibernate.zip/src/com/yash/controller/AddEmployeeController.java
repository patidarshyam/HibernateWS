package com.yash.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.model.Employee;
import com.yash.service.EmployeeService;
import com.yash.serviceimpl.EmployeeServiceImpl;

/**
 * Servlet implementation class AddEmployeeController
 */
@WebServlet("/AddEmployeeController")
public class AddEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private EmployeeService employeeService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmployeeController() {
        super();
        employeeService=new EmployeeServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//boolean result=employeeService.editEmployeeById(id);
		
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String email=request.getParameter("email");
		String userId=request.getParameter("userId");
		String password=request.getParameter("password");
		Long id=Long.parseLong(request.getParameter("id"));
		Employee employee=new Employee(firstName, lastName, email, userId, password);
		
		boolean result=employeeService.editEmployeeById(id,employee);
		if(result==true){
			request.getRequestDispatcher("/home.jsp?msg=cEdit").forward(request, response);
		}else{
			//TODO
		}
	}

}
