package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.model.Employee;
import com.yash.service.EmployeeService;
import com.yash.serviceimpl.EmployeeServiceImpl;

/**
 * Servlet implementation class DeleteContactController
 */
@WebServlet("/EditEmployeeController")
public class EditEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private EmployeeService employeeService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditEmployeeController() {
        super();
        employeeService=new EmployeeServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId=request.getParameter("id");
		System.out.println("-----------------user id-------------"+userId);
	//	boolean result=employeeService.editEmployeeById(id);
		Employee employee= employeeService.getEmployeeByUserId(userId);
	//	System.out.println("-----------------id-------------"+employee.getId());
		request.setAttribute("employee",employee);
		getServletContext().getRequestDispatcher("/editform.jsp?act=update&id="+employee.getId()).forward(request, response);
		
		
		  
	}

}
