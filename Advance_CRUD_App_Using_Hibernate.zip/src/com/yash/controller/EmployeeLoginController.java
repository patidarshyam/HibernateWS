package com.yash.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.yash.model.Employee;
import com.yash.service.EmployeeService;
import com.yash.serviceimpl.EmployeeServiceImpl;


/**
 * Servlet implementation class UserLoginController
 */
@WebServlet("/EmployeeLoginController")
public class EmployeeLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService employeeService=null;
	public EmployeeLoginController() {
		employeeService=new EmployeeServiceImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userId= request.getParameter("userId");
		String password= request.getParameter("password");
		
		boolean result=employeeService.authenticateEmployee(userId, password);
		
		Employee loggedInEmployee=employeeService.getEmployeeByUserId(userId);
		if(result==true){
			request.getSession().setAttribute("loggedInEmployee",loggedInEmployee);
			response.sendRedirect("./home.jsp");
		}else{
			response.sendRedirect("./error.jsp");
		}
	}

}
