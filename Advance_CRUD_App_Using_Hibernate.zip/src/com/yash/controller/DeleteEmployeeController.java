package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yash.service.EmployeeService;
import com.yash.serviceimpl.EmployeeServiceImpl;

/**
 * Servlet implementation class DeleteContactController
 */
@WebServlet("/DeleteEmployeeController")
public class DeleteEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private EmployeeService employeeService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteEmployeeController() {
        super();
        employeeService=new EmployeeServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("id============="+request.getParameter("id"));
		Long id=Long.parseLong(request.getParameter("id"));
		boolean result=employeeService.deleteEmployeeById(id);
		request.getRequestDispatcher("/home.jsp?msg=cDelete").forward(request, response);
		
		  
	}

}
