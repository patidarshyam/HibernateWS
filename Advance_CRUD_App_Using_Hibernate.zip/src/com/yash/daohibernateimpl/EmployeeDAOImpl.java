package com.yash.daohibernateimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.yash.dao.EmployeeDAO;
import com.yash.hibernate.util.HibernateUtil;
import com.yash.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean insert(Employee employee) {
		//code to insert employee received from service layer
		Session session=HibernateUtil.openSession();
		if(isEmployeeExist(employee))	return false;
		
		Transaction tx=null;
		try{
		tx=session.getTransaction();
		tx.begin();
		session.saveOrUpdate(employee);
		tx.commit();
		}catch (HibernateException ex) {
			if(tx!=null){
				tx.rollback();
			}
			ex.printStackTrace();
		}finally {
			session.close();
		}
		
		return true;
		
	}

	@Override
	public boolean update(Long id,Employee employee) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query = session.createQuery("update Employee set firstName='"+employee.getFirstName()+"' ,lastName='"+ employee.getLastName()+"' ,email='"+employee.getEmail()+"',userId='"+employee.getUserId()+"',password='"+employee.getPassword()+"' where id="+id);
			int resultQ= query.executeUpdate();
			if(resultQ==1){
				result=true;
			}
			tx.commit();
			}
			catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		return result;
		
		/*Query query = session.createQuery("update Stock set stockName = :stockName" +
    				" where stockCode = :stockCode");
query.setParameter("stockName", "DIALOG1");
query.setParameter("stockCode", "7277");
int result = query.executeUpdate();
		 * */
	}

	@Override
	public boolean delete(Long id) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("delete Employee where id='"+id+"'");
			int resultQ= query.executeUpdate();
			if(resultQ==1){
				result=true;
			}
			tx.commit();
			}
			catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		return result;
	}

	@Override
	public Employee getEmployeeById(String userId) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		Employee employee=new Employee();
		try{
		tx=session.getTransaction();
		tx.begin();
		Query query=session.createQuery("from Employee where userId='"+userId+"'");
		employee=(Employee)query.uniqueResult();
		tx.commit();
		}
		catch (HibernateException ex) {
			if(tx!=null){
				tx.rollback();
			}
			ex.printStackTrace();
		}finally {
			session.close();
		}
		return employee;
	}

	@Override
	public List<Employee> showAllEmployees() {
		List<Employee> employeeList=new ArrayList<>();
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		try{
			tx=session.getTransaction();
			tx.begin();
			employeeList=session.createQuery("from Employee").list();
			tx.commit();
			}catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		
		return employeeList;
	}

	@Override
	public boolean isEmployeeExist(Employee employee) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("from Employee where userId='"+employee.getUserId()+"'");
			Employee emp=(Employee) query.uniqueResult();
			tx.commit();
			if(emp!=null) result=true;
			
			}catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}

		return result;
	}

	@Override
	public boolean authenticateEmployee(String userId, String password) {
		Employee employee=getEmployeeById(userId);
		
		if(employee!=null && employee.getUserId().equals(userId) && employee.getPassword().equals(password)){
			return true;
		}
		else{
			return false;
		}
	}

}
