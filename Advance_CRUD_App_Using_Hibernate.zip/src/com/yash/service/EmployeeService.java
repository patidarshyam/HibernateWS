package com.yash.service;

import java.util.List;

import com.yash.model.Employee;

public interface EmployeeService {
	/**
	 * This method authenticate the employee using userId and password.
	 * @param userId
	 * @param password
	 * @return boolean
	 */
	public boolean authenticateEmployee(String userId, String password);

	/**
	 *This method search the employee by userId
	 * @return Employee
	 */
	public Employee getEmployeeByUserId(String userId);
	
	/**
	 * This method will give the list of employees
	 * @return List<Employee>
	 */
	List<Employee> getListOfEmployees();
	/**
	 * This method register the employee.
	 * @param employee
	 * @return boolean
	 */
	public boolean register(Employee employee);
	/**
	 * this method delete employee by id
	 * @param id
	 */
	public boolean deleteEmployeeById(Long id);
	/**
	 * this method edit employee by id
	 * @param id
	 */
	public boolean editEmployeeById(Long id,Employee employee);
	
}
