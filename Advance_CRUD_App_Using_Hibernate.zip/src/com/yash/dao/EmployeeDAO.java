package com.yash.dao;

import java.util.List;

import com.yash.model.Employee;

public interface EmployeeDAO {
	
	/**
	 * insert() method insert the employee into employeeRepository
	 */
	public boolean insert(Employee employee);
	
	/**
	 * This method update the employee details
	 */
	public boolean update(Long id,Employee employee);
	
	/**
	 * delete(Long) method delete the employee from employeeRepository
	 */
	public boolean delete(Long id);
	/**
	 * This method search the employee by userId
	 * @return Employee
	 */
	public Employee getEmployeeById(String userId);
	
	/**
	 * showAllEmployees() method will give the list of employees
	 * @return List<Employee>
	 */
	List<Employee> showAllEmployees();
	/**
	 * This method tells that employee is exist or not
	 * @param employee
	 * @return boolean
	 */
	public boolean isEmployeeExist(Employee employee);
	/**
	 * This method authenticate the employee using userId and password.
	 * @param userId
	 * @param password
	 * @return boolean
	 */
	public boolean authenticateEmployee(String userId, String password);
}
