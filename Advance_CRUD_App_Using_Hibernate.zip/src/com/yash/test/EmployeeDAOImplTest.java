package com.yash.test;

import static org.junit.Assert.*;

import java.util.List;

import org.hibernate.hql.internal.ast.tree.BooleanLiteralNode;
import org.junit.Test;

import com.yash.dao.EmployeeDAO;
import com.yash.daohibernateimpl.EmployeeDAOImpl;
import com.yash.model.Employee;

public class EmployeeDAOImplTest {

//	@Test
//	public void insertTest() {
//		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
//		String firstName="sour";
//		String lastName="patidar";
//		String userId="sour";
//		String password="sour123";
//		String email="sour@123";
//		Employee employee = new Employee(firstName, lastName, email, userId, password);
//		boolean result=employeeDAO.insert(employee);
//		assertEquals(true, result);
//	}
//	@Test
//	public void getEmployeeByIdTest(){
//		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
//		Employee emp=employeeDAO.getEmployeeById("shyam");
//		//assertEquals("shyam@123", emp.getEmail());
//		assertNotEquals(null, emp);
//	}
//	@Test
//	public void showAllEmployeesTest(){
//		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
//		List<Employee> employeeList=employeeDAO.showAllEmployees();
//		
//		//assertEquals("maithili@123", employeeList.get(1).getEmail());
//		assertNotEquals(null, employeeList);
//	}
//	@Test
//	public void isEmployeeExistTest(){
//		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
//		Employee employee=new Employee();
//		employee.setUserId("shyam");
//		boolean result=employeeDAO.isEmployeeExist(employee);
//		
//		assertEquals(true, result);
//	}
//	@Test
//	public void authenticateEmployeeTest(){
//		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
//		String userId="shyam";
//		String password="shyam123";
//		boolean result=employeeDAO.authenticateEmployee(userId, password);
//		
//		assertEquals(true, result);
//	}
//	@Test
//	public void deleteTest(){
//		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
//		Long id=(long) 9;
//		boolean result=employeeDAO.delete(id);
//		
//		assertEquals(true, result);
//	}
	@Test
	public void updateTest(){
		EmployeeDAO employeeDAO=new EmployeeDAOImpl();
		Long id=(long) 11;
		String firstName="sour";
		String lastName="patidar";
		String userId="sour";
		String password="sour123";
		String email="sour@123";
		Employee employee = new Employee(firstName, lastName, email, userId, password);
		
		boolean result=employeeDAO.update(id, employee);
		
		assertEquals(true, result);
	}
}
