package com.yash.test;

import static org.junit.Assert.*;

import java.util.List;

import org.hibernate.hql.internal.ast.tree.BooleanLiteralNode;
import org.junit.Test;

import com.yash.dao.EmployeeDAO;
import com.yash.daohibernateimpl.EmployeeDAOImpl;
import com.yash.model.Employee;
import com.yash.serviceimpl.EmployeeServiceImpl;

public class EmployeeServiceImplTest {

	@Test
	public void registerTest() {
		EmployeeServiceImpl employeeServiceImpl=new EmployeeServiceImpl();
		String firstName="sachin";
		String lastName="patidar";
		String userId="sachin";
		String password="sachin123";
		String email="sachin@123";
		Employee employee = new Employee(firstName, lastName, email, userId, password);
		boolean result=employeeServiceImpl.register(employee);
		assertEquals(true, result);
	}
	@Test
	public void getEmployeeByUserId(){
		EmployeeServiceImpl employeeServiceImpl=new EmployeeServiceImpl();
		Employee emp=employeeServiceImpl.getEmployeeByUserId("savan");
		//assertEquals("savan@123", emp.getEmail());
		assertNotEquals(null, emp);
	}
	@Test
	public void getListOfEmployees(){
		EmployeeServiceImpl employeeServiceImpl=new EmployeeServiceImpl();
		List<Employee> employeeList=employeeServiceImpl.getListOfEmployees();
		
		//assertEquals("maithili@123", employeeList.get(1).getEmail());
		assertNotEquals(null, employeeList);
	}
	
	@Test
	public void authenticateEmployeeTest(){
		EmployeeServiceImpl employeeServiceImpl=new EmployeeServiceImpl();
		String userId="shyam";
		String password="shyam123";
		boolean result=employeeServiceImpl.authenticateEmployee(userId, password);
		
		assertEquals(true, result);
	}
}
