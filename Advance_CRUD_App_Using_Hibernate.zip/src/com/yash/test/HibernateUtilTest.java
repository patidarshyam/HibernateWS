package com.yash.test;

import static org.junit.Assert.*;

import org.hibernate.Session;
import org.junit.Test;

import com.yash.hibernate.util.HibernateUtil;

public class HibernateUtilTest {
	

	@Test
	public void openSessionTest() {
		HibernateUtil hibernateUtil=new HibernateUtil();
		Session session=null;
		session=hibernateUtil.openSession();
		assertEquals(session,session);
		
	}

}
