package com.yash.cms.model;

import javax.persistence.*;

/**
 * This class will be work as a model object.
 * Its use is to travel data from one layer to another layer.
 * @author shyam.patidar
 *
 */

//TODO Mapping OneTOMany or ManyToOne
@Entity
public class Contact extends Person {
	@ManyToOne
	@JoinColumn(name="userId")
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

//	/**
//	 * userId of the User
//	 */
//	@Column(nullable=false)
//	private Integer userId;
//
//	public Integer getUserId() {
//		return userId;
//	}
//
//	public void setUserId(Integer userId) {
//		this.userId = userId;
//	}
	
}
