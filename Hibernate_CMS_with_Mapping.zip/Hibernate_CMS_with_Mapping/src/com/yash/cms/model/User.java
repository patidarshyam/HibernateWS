package com.yash.cms.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

/**
 * This class will be work as a model object.
 * Its use is to travel data from one layer to another layer.
 * @author shyam.patidar
 *
 */

//TODO Mapping OneTOMany or ManyToOne

@Entity
public class User extends Person {
	
	@OneToMany(mappedBy="user")
	private List<Contact> contacts=new ArrayList<>();	
	
	public List<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}
	
	/**
	 * status of user like active or blocked
	 */
	@Column( nullable = false, columnDefinition = "int default 1")
	private Integer status=1;
	/**
	 * role of user like Guest or Admin
	 */
	@Column( nullable = false, columnDefinition = "int default 1")
	private Integer role=1;
	/**
	 * loginName of user
	 */
	@Column(nullable=false)
	private String loginName;
	/**
	 * password of user
	 */
	@Column(nullable=false)
	private String password;
	public User() {
		// TODO Auto-generated constructor stub
	}

	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getRole() {
		return role;
	}
	public void setRole(Integer role) {
		this.role = role;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
