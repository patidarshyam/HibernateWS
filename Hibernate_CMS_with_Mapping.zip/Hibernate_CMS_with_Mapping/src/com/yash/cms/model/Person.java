package com.yash.cms.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;



/**
 * This class will not be used as a shared resource, that will be used as a shared resource,
 * that will provide common attribute to its subclass.
 * 
 * @author shyam.patidar
 *
 */
@MappedSuperclass
public class Person {
	
	/**
	 * id of person.
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	/**
	 * name of person.
	 */
	@Column(nullable=false)
	private String name;
	/**
	 * contact of person.
	 */
	@Column(nullable=false)
	private String contact;
	/**
	 * address of person.
	 */
	private String address;
	/**
	 * email of person.
	 */
	private String email;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
