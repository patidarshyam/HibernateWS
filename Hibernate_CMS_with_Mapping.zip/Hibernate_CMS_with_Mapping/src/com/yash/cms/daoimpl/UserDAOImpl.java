package com.yash.cms.daoimpl;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.model.User;
import com.yash.cms.util.HibernateUtil;


/**
 * This class perform the operation related to users.
 * @author shyam.patidar
 *
 */
public class UserDAOImpl implements UserDAO {
	private static Logger logger= Logger.getLogger(UserDAOImpl.class);
	
	public boolean isUserExist(User user) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("from User where loginName=:lname");
			query.setParameter("lname", user.getLoginName());
			User emp=(User) query.uniqueResult();
			tx.commit();
			if(emp!=null) result=true;
			
			}catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}

		return result;
	}
	
	@Override
	public boolean insert(User user) {

		Session session=HibernateUtil.openSession();
		if(isUserExist(user))	return false;
		
		Transaction tx=null;
		try{
		tx=session.getTransaction();
		tx.begin();
		session.saveOrUpdate(user);
		tx.commit();
		}catch (HibernateException ex) {
			if(tx!=null){
				tx.rollback();
			}
			ex.printStackTrace();
		}finally {
			session.close();
		}
		return true;
	
	}

	@Override
	public boolean delete(Integer userId) {
		return false;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean delete(User user) {
		return false;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean update(Integer userId) {
		return false;
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}


}
