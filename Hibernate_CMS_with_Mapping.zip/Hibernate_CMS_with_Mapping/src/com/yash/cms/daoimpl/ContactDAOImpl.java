package com.yash.cms.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.model.Contact;
import com.yash.cms.model.User;
import com.yash.cms.util.HibernateUtil;


public class ContactDAOImpl implements ContactDAO {
	
	@Override
	public boolean insert(Contact contact) {
		Session session=HibernateUtil.openSession();
		Transaction tx=null;
		try{
		tx=session.getTransaction();
		tx.begin();
		session.saveOrUpdate(contact);
		tx.commit();
		}catch (HibernateException ex) {
			if(tx!=null){
				tx.rollback();
			}
			ex.printStackTrace();
		}finally {
			session.close();
		}
		return true;
		
	}

	
	@Override
	public List<Contact> listContact(Integer userId) {
		
		List<Contact> contactList=new ArrayList<>();
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("from Contact where userId=:userId");
			query.setParameter("userId", userId);
			contactList=query.list();
			
			tx.commit();
			}catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		
		return contactList;
	}

	@Override
	public boolean delete(Integer contactId) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("delete Contact where id=:id");
			query.setParameter("id", contactId);
			int resultQ= query.executeUpdate();
			if(resultQ==1){
				result=true;
			}
			tx.commit();
			}
			catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		return result;
		
	}

	@Override
	public boolean update(Contact contact) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query = session.createQuery("UPDATE Contact SET name=:name, contact=:contact ,userId=:userId ,address=:address ,email=:email WHERE id=:id");
			query.setParameter("name", contact.getName());
			query.setParameter("contact", contact.getContact());
			query.setParameter("userId", contact.getUser());
			query.setParameter("address", contact.getAddress());
			query.setParameter("email", contact.getEmail());
			query.setInteger("id", contact.getId());
			int resultQ= query.executeUpdate();
			if(resultQ==1){
				result=true;
			}
			tx.commit();
			}
			catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		return result;
		
	}

	@Override
	public Contact select(Integer contactId) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		boolean result=false;
		Contact contact=new Contact();
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery("from Contact where id=:id");
			query.setParameter("id", contactId);
			contact=(Contact) query.uniqueResult();
			tx.commit();
			if(contact!=null) result=true;
			
			}catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		
		return contact;
	}

	@Override
	public List<Contact> listContact(String search, Integer userId) {
		List<Contact> contactList=new ArrayList<>();
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		String likeSearch="%"+search+"%";
		String hql="FROM Contact WHERE userId=:userId AND (name LIKE :likeSearch OR email LIKE :likeSearch OR address LIKE :likeSearch OR contact LIKE:likeSearch)";
		
		try{
			tx=session.getTransaction();
			tx.begin();
			Query query=session.createQuery(hql);
			query.setParameter("likeSearch", likeSearch);
			query.setInteger("userId", userId);
			contactList=query.list();
			tx.commit();
			}catch (HibernateException ex) {
				if(tx!=null){
					tx.rollback();
				}
				ex.printStackTrace();
			}finally {
				session.close();
			}
		
		return contactList;
	
	}

	

}
