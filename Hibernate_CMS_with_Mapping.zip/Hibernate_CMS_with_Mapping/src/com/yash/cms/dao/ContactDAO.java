package com.yash.cms.dao;

import java.util.List;
import com.yash.cms.model.Contact;
import com.yash.cms.model.User;


/**
 * This interface perform the operation related to contact.
 * @author shyam.patidar
 *
 */
public interface ContactDAO {
	/**
	 * This will add the contact into DB
	 * @param contact Object
	 * @return 
	 */
	public boolean insert(Contact contact);
	/**
	 * This will delete the contact from DB
	 * @param contactId
	 */
	public boolean delete(Integer contactId);

	/**
	 * This will update the user into DB
	 * @param userId
	 */
	public Contact select(Integer contactId);

	/**
	 * This will return list of contact from DB by userId
	 * @param user object
	 */
	public List<Contact> listContact(Integer userId);
	/**
	 * This will update the contact into DB
	 * @param contact
	 */
	public boolean update(Contact contact);
	/**
	 * This will return list of contact from DB by any String data provided and userId.
	 * @param search
	 */
	public List<Contact> listContact(String search,Integer userId);

}
