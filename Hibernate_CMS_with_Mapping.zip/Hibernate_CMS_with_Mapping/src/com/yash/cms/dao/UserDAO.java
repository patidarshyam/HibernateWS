package com.yash.cms.dao;
import java.util.List;

import com.yash.cms.model.User;
/**
 * This interface perform the operation related to users.
 * @author shyam.patidar
 *
 */
public interface UserDAO {
	/**
	 * This will add the user into DB
	 * @param user Object
	 *@return boolean
	 */
	public boolean insert(User user);
	/**
	 * This will delete the user from DB
	 * @param userId
	 * @return boolean
	 */
	public boolean delete(Integer userId);
	/**
	 * This will delete the user from DB
	 * @param user object
	 * @return boolean
	 */
	public boolean delete(User user);
	/**
	 * This will update the user into DB
	 * @param userId
	 * @return boolean
	 */
	public boolean update(Integer userId);
	/**
	 * This will List users from the users table from DB
	 * @return
	 */
	public List<User> list();
	/**
	 * This method check the user into database and return true or false.
	 * @param user
	 * @return boolean
	 */
	public boolean isUserExist(User user);

}
