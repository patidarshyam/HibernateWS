package com.yash.cms.test;

import java.util.List;

import com.yash.cms.dao.ContactDAO;
import com.yash.cms.daoimpl.ContactDAOImpl;
import com.yash.cms.model.Contact;

public class ContactDAOImplTest {

	public static void main(String[] args) {
		//insert check
//				ContactDAO contactDAO=new ContactDAOImpl();
//				Contact contact = new Contact();
//				contact.setName("Manan");
//				contact.setContact("5654666363");
//				contact.setUserId(1);
//				contactDAO.insert(contact);
				
				//update check
//				ContactDAO contactDAO=new ContactDAOImpl();
//				Contact contact = new Contact();
//				contact.setName("Mohan");
//				contact.setContact("9847444470");
//				contact.setUserId(5);
//				contact.setId(3);
//				contact.setAddress("Bhopal");
//				contact.setEmail("c@123");
//				contactDAO.update(contact);

			//delete by id check
//				ContactDAO contactDAO=new ContactDAOImpl();
//				contactDAO.delete(2);
		
		//list contact search by userid check
//		ContactDAO contactDAO=new ContactDAOImpl();
//		List<Contact> contacts=contactDAO.listContact(5);
//		for (Contact contact : contacts) {
//			System.out.println("---------contact name----------"+contact.getName());
//			
//		}
		
			//list contact search by userid and String search check
//				ContactDAO contactDAO=new ContactDAOImpl();
//				List<Contact> contacts=contactDAO.listContact("s", 5);
//				for (Contact contact : contacts) {
//					System.out.println("---------contact name----------"+contact.getName());
//					
//				}
				
//				//select check
//				ContactDAO contactDAO=new ContactDAOImpl();
//				Contact contact = new Contact();
//				contact=contactDAO.select(3);
//				System.out.println("---------contact name----------"+contact.getName());
	}

}
