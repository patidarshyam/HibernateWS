package com.yash.cms.test;

import org.hibernate.Session;

import com.yash.cms.util.HibernateUtil;

public class HibernateUtilTest {
	
	public static void main(String[] args) {

		HibernateUtil hibernateUtil=new HibernateUtil();
		Session session=null;
		session=hibernateUtil.openSession();
		System.out.println("---------------------------------------------------------------"+session.toString());
	}
	
}
