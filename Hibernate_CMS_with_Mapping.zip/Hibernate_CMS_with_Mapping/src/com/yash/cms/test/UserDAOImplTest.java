package com.yash.cms.test;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.UserServiceImpl;

public class UserDAOImplTest {

	public static void main(String[] args) {
		//insert check
		UserDAO userDAO=new UserDAOImpl();
		User user = new User();
		user.setName("Mahi");
		user.setContact("565400003");
		user.setLoginName("mahi");
		user.setPassword("mahi123");
		userDAO.insert(user);
	}

}
