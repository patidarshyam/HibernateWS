package com.yash.cms.test;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.model.User;

public class UserServiceImplTest {

	public static void main(String[] args) {
		UserDAO userDAO= new UserDAOImpl();
		User user = new User();
		user.setName("Mohan");
		user.setContact("566363");
		user.setLoginName("mohan");
		user.setPassword("mohan123");
		userDAO.insert(user);
	}

}
