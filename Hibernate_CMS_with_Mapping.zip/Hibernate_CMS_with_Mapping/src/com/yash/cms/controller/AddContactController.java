package com.yash.cms.controller;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cms.model.Contact;
import com.yash.cms.model.User;
import com.yash.cms.service.ContactService;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.ContactServiceImpl;
import com.yash.cms.serviceimpl.UserServiceImpl;
import com.yash.cms.util.HibernateUtil;

/**
 * Servlet implementation class AddContactController
 */
@WebServlet("/AddContactController")
public class AddContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private  ContactService contactService=null;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddContactController() {
        super();
        contactService=new ContactServiceImpl();
    }
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	HttpSession session = request.getSession();
		if(session.getAttribute("userId")!=null){
		
	    	Contact contact=new Contact();
	    	contact.setName(request.getParameter("name"));
	    	contact.setContact(request.getParameter("contact"));
	    	contact.setAddress(request.getParameter("address"));
	    	contact.setEmail(request.getParameter("email"));
	    	//contact.setUserId((Integer)request.getSession().getAttribute("userId"));
	    	User user=(User) request.getSession().getAttribute("user");
	    	contact.setUser(user);
	    	
	    	String msg = null;
	    	
	    	if(request.getParameter("act").equals("update")){
	    		contact.setId(Integer.parseInt(request.getParameter("id")));
	    		msg="cUpdate";
	    		contactService.updateContact(contact);
	    	}else{
	    		msg="cAdd";
	    		contactService.addContact(contact);
	    	}
	    	request.getRequestDispatcher("PrepareContactListController?msg="+msg).forward(request, response);
	    }else{
	    	response.sendRedirect("./index.jsp");
	    }
    }
}
