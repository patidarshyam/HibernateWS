package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class UpdateContactController
 */
@WebServlet("/UpdateContactController")
public class UpdateContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ContactService contactService=null; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateContactController() {
        super();
        contactService=new ContactServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		HttpSession session = request.getSession();
		if(session.getAttribute("userId")!=null){
			
			Integer contactId=Integer.parseInt(request.getParameter("id"));
			Contact contact= contactService.getContact(contactId);
			request.setAttribute("contact",contact);
			getServletContext().getRequestDispatcher("/addcontact.jsp?act=update&id="+contact.getId()).forward(request, response);
		}else{
			response.sendRedirect("./index.jsp");
		}
	}

}
