package com.yash.cms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserLoginController
 */
@WebServlet("/UserLoginController")
public class UserLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 private  UserService userService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginController() {
        userService=new UserServiceImpl();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String loginName=request.getParameter("loginName");
		String password=request.getParameter("password");
		
		if(loginName.isEmpty() && password.isEmpty()){
			response.sendRedirect("./index.jsp?err=login failed! LoginName and Password can not be empty!");
		}else if(loginName.isEmpty()){
			response.sendRedirect("./index.jsp?err=login failed! LoginName can not be empty!");
		}else if(password.isEmpty()){
			response.sendRedirect("./index.jsp?err=login failed! Password can not be empty!");
		}else{
		System.out.println(request.getParameter("loginName")+"-------------------------"+request.getParameter("password"));
		User user=userService.userAuthentication(loginName,password);
		if(user!=null){
			HttpSession session = request.getSession();
			 session.setMaxInactiveInterval(60);
			session.setAttribute("userId",user.getId());
			session.setAttribute("user",user);
			session.setAttribute("userName",user.getName());
			response.sendRedirect("./guest_dashboard.jsp");
		
		}else{
			response.sendRedirect("./index.jsp?err=login failed! Please check loginName and Password");
		}
		}
	}

}
