package com.yash.cms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class SearchContactController
 */
@WebServlet("/SearchContactController")
public class SearchContactController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private  ContactService contactService=null;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchContactController() {
        super();
        contactService=new ContactServiceImpl();
    }
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		HttpSession session = request.getSession();
		if(session.getAttribute("userId")!=null){
			String search= request.getParameter("search");
			if(search.isEmpty()){
				request.getRequestDispatcher("PrepareContactListController?msg=searchEmpty").forward(request, response);
			}
			else{
			Integer userId=(Integer)request.getSession().getAttribute("userId");
			List<Contact> contacts= contactService.searchData(search,userId);
			request.setAttribute("contactList",contacts);
			String msg="search";
			request.getRequestDispatcher("/contact_list.jsp?msg="+msg).forward(request, response);
			}
	
		}else{
			response.sendRedirect("./index.jsp");
		}
	}
}
