package com.yash.cms.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.cms.model.Contact;
import com.yash.cms.service.ContactService;
import com.yash.cms.serviceimpl.ContactServiceImpl;

/**
 * Servlet implementation class PrepareContactListController
 */
@WebServlet("/PrepareContactListController")
public class PrepareContactListController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	    private ContactService contactService=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PrepareContactListController() {
        super();
        contactService=new ContactServiceImpl();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Contact> contacts=contactService.getAllContactByUserId((Integer)request.getSession().getAttribute("userId"));
		request.setAttribute("contactList",contacts);
		String msg=null;
		msg=request.getParameter("msg");
		//response.sendRedirect("contact_list.jsp");
		request.getRequestDispatcher("/contact_list.jsp?act='"+msg+"'").forward(request, response);
		
	}

}
