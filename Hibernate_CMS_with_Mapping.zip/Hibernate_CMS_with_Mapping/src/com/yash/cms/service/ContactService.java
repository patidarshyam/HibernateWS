package com.yash.cms.service;

import java.util.List;
import com.yash.cms.model.Contact;

/**
 * This will perform service related task on contact.
 * @author shyam.patidar
 *
 */
public interface ContactService {
	/**
	 * This will add the contact
	 * @param contact object
	 */
	public void addContact(Contact contact);
	/**
	 * This will delete the contact
	 * @param contactId
	 */
	public void deleteContact(Integer contactId);
	/**
	 * This will List the contacts
	 * @param userId
	 */
	public List<Contact> getAllContactByUserId(Integer userId);
	/**
	 * This will update the contact
	 * @param contact object
	 */
	public void updateContact(Contact contact);
	/**
	 * This will get the contact object
	 * @param contactId
	 */
	public Contact getContact(Integer contactId);
	/**
	 * This will get the contacts by provided string and userId
	 * @param search
	 */
	
	public List<Contact> searchData(String search,Integer userId);
	
		

}
