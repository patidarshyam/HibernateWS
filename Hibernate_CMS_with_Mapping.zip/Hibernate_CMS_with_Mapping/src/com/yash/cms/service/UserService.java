package com.yash.cms.service;

import com.yash.cms.model.User;

/**
 * This will perform service related task on user.
 * @author shyam.patidar
 *
 */
public interface UserService {
	/**
	 * This will register the user
	 * @param user object
	 */
	public void registerUser(User user);
	/**
	 * This will Authenticate the user with provided loginName and Password.
	 * @param user object which include loginName and password
	 *
	 * @return Person name
	 */
	public User userAuthentication(String loginName,String password);

}
