package com.yash.cms.serviceimpl;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.yash.cms.dao.UserDAO;
import com.yash.cms.daoimpl.UserDAOImpl;
import com.yash.cms.model.User;
import com.yash.cms.service.UserService;
import com.yash.cms.util.HibernateUtil;

public class UserServiceImpl implements UserService{
	private static Logger logger= Logger.getLogger(UserServiceImpl.class);
	private UserDAO userDAO=null;
	public UserServiceImpl() {
		userDAO= new UserDAOImpl(); //DI (Dependency Injection)
	}

	@Override
	public void registerUser(User user) {
		userDAO.insert(user);
	}

	@Override
	public User userAuthentication(String loginName,String password) {
		Session session= HibernateUtil.openSession();
		Transaction tx=null;
		User user=new User();
		user=null;
		try{
		tx=session.getTransaction();
		tx.begin();
		
	//	Query query=session.createQuery("from User where loginName='"+loginName+"' and password='"+password+"'");  // This will cause sql injection.
		
		
		Query query=session.createQuery("from User where loginName=:lname and password=:pass");
		query.setParameter("lname", loginName);
		query.setParameter("pass", password);
		user=(User) query.uniqueResult();
		tx.commit();
		}
		catch (HibernateException ex) {
			if(tx!=null){
				tx.rollback();
			}
			ex.printStackTrace();
		}finally {
			session.close();
		}
		return user;
			
	}
}
