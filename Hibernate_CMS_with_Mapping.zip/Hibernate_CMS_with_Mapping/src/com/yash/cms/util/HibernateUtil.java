package com.yash.cms.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

/**
 * This class will perform operation related to DB like connection, disconnect, providing
 * preparedStatement object and ResultSet object. This class will be responsible to have
 * transaction complete operation as well like closing connection, PreparedStatement object etc.
 * @author shyam.patidar
 *
 */
public class HibernateUtil {
private static final SessionFactory sessionFactory;
	
	static{
		try{
		sessionFactory=	new	AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory();
		}catch(Throwable ex){
			System.err.println("initial SessionFactory creation failure."+ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	
	public static Session openSession(){
		return sessionFactory.openSession();
	}

	
}
